--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Debian 15.4-1.pgdg120+1)
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "UWB";
--
-- Name: UWB; Type: DATABASE; Schema: -; Owner: uwb
--

CREATE DATABASE "UWB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "UWB" OWNER TO uwb;

\connect "UWB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: anchor; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.anchor (
    id bigint NOT NULL,
    created_by character varying(255),
    created_date timestamp(6) without time zone,
    deleted boolean,
    modified_by character varying(255),
    modified_date timestamp(6) without time zone,
    name character varying(30),
    x double precision,
    x_px double precision,
    y double precision,
    y_px double precision,
    z double precision,
    background_id bigint NOT NULL
);


ALTER TABLE public.anchor OWNER TO uwb;

--
-- Name: anchor_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.anchor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.anchor_id_seq OWNER TO uwb;

--
-- Name: anchor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.anchor_id_seq OWNED BY public.anchor.id;


--
-- Name: area; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.area (
    id bigint NOT NULL,
    created_by character varying(255),
    created_date timestamp(6) without time zone,
    deleted boolean,
    modified_by character varying(255),
    modified_date timestamp(6) without time zone,
    color character varying(10),
    name character varying(50),
    area_type_id bigint NOT NULL,
    background_id bigint NOT NULL
);


ALTER TABLE public.area OWNER TO uwb;

--
-- Name: area_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.area_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.area_id_seq OWNER TO uwb;

--
-- Name: area_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.area_id_seq OWNED BY public.area.id;


--
-- Name: area_type; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.area_type (
    id bigint NOT NULL,
    created_by character varying(255),
    created_date timestamp(6) without time zone,
    deleted boolean,
    modified_by character varying(255),
    modified_date timestamp(6) without time zone,
    color character varying(10),
    name character varying(50),
    organization_unit_id bigint NOT NULL
);


ALTER TABLE public.area_type OWNER TO uwb;

--
-- Name: area_type_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.area_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.area_type_id_seq OWNER TO uwb;

--
-- Name: area_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.area_type_id_seq OWNED BY public.area_type.id;


--
-- Name: area_vertex; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.area_vertex (
    id bigint NOT NULL,
    lp integer,
    x double precision,
    y double precision,
    area_id bigint NOT NULL
);


ALTER TABLE public.area_vertex OWNER TO uwb;

--
-- Name: area_vertex_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.area_vertex_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.area_vertex_id_seq OWNER TO uwb;

--
-- Name: area_vertex_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.area_vertex_id_seq OWNED BY public.area_vertex.id;


--
-- Name: areas_notifications; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.areas_notifications (
    notification_id bigint NOT NULL,
    area_id bigint NOT NULL
);


ALTER TABLE public.areas_notifications OWNER TO uwb;

--
-- Name: background; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.background (
    id bigint NOT NULL,
    created_by character varying(255),
    created_date timestamp(6) without time zone,
    deleted boolean,
    modified_by character varying(255),
    modified_date timestamp(6) without time zone,
    file_name character varying(255),
    file_size double precision,
    name character varying(50),
    path character varying(255),
    scale double precision,
    organization_unit_id bigint NOT NULL
);


ALTER TABLE public.background OWNER TO uwb;

--
-- Name: background_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.background_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.background_id_seq OWNER TO uwb;

--
-- Name: background_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.background_id_seq OWNED BY public.background.id;


--
-- Name: localization_cache; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.localization_cache (
    id bigint NOT NULL,
    date timestamp without time zone,
    x double precision,
    y double precision,
    z double precision,
    tag_id character varying(20),
    background_id bigint,
    anchor_ids character varying
);


ALTER TABLE public.localization_cache OWNER TO uwb;

--
-- Name: localization_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

ALTER TABLE public.localization_cache ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.localization_cache_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notification_config; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.notification_config (
    id bigint NOT NULL,
    message character varying(255),
    title character varying(255),
    notification_type_id bigint NOT NULL
);


ALTER TABLE public.notification_config OWNER TO uwb;

--
-- Name: notification_config_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.notification_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_config_id_seq OWNER TO uwb;

--
-- Name: notification_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.notification_config_id_seq OWNED BY public.notification_config.id;


--
-- Name: notification_type; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.notification_type (
    id bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.notification_type OWNER TO uwb;

--
-- Name: notification_type_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.notification_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_type_id_seq OWNER TO uwb;

--
-- Name: notification_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.notification_type_id_seq OWNED BY public.notification_type.id;


--
-- Name: organization_unit; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.organization_unit (
    deleted boolean,
    created_date timestamp(6) without time zone,
    id bigint NOT NULL,
    modified_date timestamp(6) without time zone,
    parent_organization_unit_id bigint,
    created_by character varying(255),
    modified_by character varying(255),
    name character varying(100),
    tree_path character varying(255)
);


ALTER TABLE public.organization_unit OWNER TO uwb;

--
-- Name: organization_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.organization_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organization_unit_id_seq OWNER TO uwb;

--
-- Name: organization_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.organization_unit_id_seq OWNED BY public.organization_unit.id;


--
-- Name: role; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.role (
    id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.role OWNER TO uwb;

--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_id_seq OWNER TO uwb;

--
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- Name: tag_a28we1; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.tag_a28we1 (
    id bigint NOT NULL,
    date timestamp without time zone,
    x double precision,
    y double precision,
    z double precision,
    tag_id character varying(20),
    background_id bigint,
    anchor_ids character varying
);


ALTER TABLE public.tag_a28we1 OWNER TO uwb;

--
-- Name: tag_a28we1_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.tag_a28we1_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tag_a28we1_id_seq OWNER TO uwb;

--
-- Name: tag_a28we1_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.tag_a28we1_id_seq OWNED BY public.tag_a28we1.id;


--
-- Name: tag_cqw34e; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.tag_cqw34e (
    id bigint NOT NULL,
    date timestamp without time zone,
    x double precision,
    y double precision,
    z double precision,
    tag_id character varying(20),
    background_id bigint,
    anchor_ids character varying
);


ALTER TABLE public.tag_cqw34e OWNER TO uwb;

--
-- Name: tag_cqw34e_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.tag_cqw34e_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tag_cqw34e_id_seq OWNER TO uwb;

--
-- Name: tag_cqw34e_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.tag_cqw34e_id_seq OWNED BY public.tag_cqw34e.id;


--
-- Name: tag_po85uxc; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.tag_po85uxc (
    id bigint NOT NULL,
    date timestamp without time zone,
    x double precision,
    y double precision,
    z double precision,
    tag_id character varying(20),
    background_id bigint,
    anchor_ids character varying
);


ALTER TABLE public.tag_po85uxc OWNER TO uwb;

--
-- Name: tag_po85uxc_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.tag_po85uxc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tag_po85uxc_id_seq OWNER TO uwb;

--
-- Name: tag_po85uxc_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.tag_po85uxc_id_seq OWNED BY public.tag_po85uxc.id;


--
-- Name: tag_poiu987; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.tag_poiu987 (
    id bigint NOT NULL,
    date timestamp without time zone,
    x double precision,
    y double precision,
    z double precision,
    tag_id character varying(20),
    background_id bigint,
    anchor_ids character varying
);


ALTER TABLE public.tag_poiu987 OWNER TO uwb;

--
-- Name: tag_poiu987_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.tag_poiu987_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tag_poiu987_id_seq OWNER TO uwb;

--
-- Name: tag_poiu987_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.tag_poiu987_id_seq OWNED BY public.tag_poiu987.id;


--
-- Name: tag_qwe12rt; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.tag_qwe12rt (
    id bigint NOT NULL,
    date timestamp without time zone,
    x double precision,
    y double precision,
    z double precision,
    tag_id character varying(20),
    background_id bigint,
    anchor_ids character varying
);


ALTER TABLE public.tag_qwe12rt OWNER TO uwb;

--
-- Name: tag_qwe12rt_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.tag_qwe12rt_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tag_qwe12rt_id_seq OWNER TO uwb;

--
-- Name: tag_qwe12rt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.tag_qwe12rt_id_seq OWNED BY public.tag_qwe12rt.id;


--
-- Name: uwb_object; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.uwb_object (
    id bigint NOT NULL,
    created_by character varying(255),
    created_date timestamp(6) without time zone,
    deleted boolean,
    modified_by character varying(255),
    modified_date timestamp(6) without time zone,
    hex_tag_id character varying(20),
    name character varying(30),
    second_name character varying(30),
    uwb_object_type_id bigint NOT NULL
);


ALTER TABLE public.uwb_object OWNER TO uwb;

--
-- Name: uwb_object_icon; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.uwb_object_icon (
    id bigint NOT NULL,
    created_by character varying(255),
    created_date timestamp(6) without time zone,
    deleted boolean,
    modified_by character varying(255),
    modified_date timestamp(6) without time zone,
    file_name character varying(255),
    name character varying(30),
    path character varying(255),
    file_size double precision,
    organization_unit_id bigint
);


ALTER TABLE public.uwb_object_icon OWNER TO uwb;

--
-- Name: uwb_object_icon_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.uwb_object_icon_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.uwb_object_icon_id_seq OWNER TO uwb;

--
-- Name: uwb_object_icon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.uwb_object_icon_id_seq OWNED BY public.uwb_object_icon.id;


--
-- Name: uwb_object_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.uwb_object_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.uwb_object_id_seq OWNER TO uwb;

--
-- Name: uwb_object_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.uwb_object_id_seq OWNED BY public.uwb_object.id;


--
-- Name: uwb_object_type; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.uwb_object_type (
    id bigint NOT NULL,
    created_by character varying(255),
    created_date timestamp(6) without time zone,
    deleted boolean,
    modified_by character varying(255),
    modified_date timestamp(6) without time zone,
    admin_only boolean,
    name character varying(50),
    organization_unit_id bigint NOT NULL,
    uwb_object_icon_id bigint NOT NULL
);


ALTER TABLE public.uwb_object_type OWNER TO uwb;

--
-- Name: uwb_object_type_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.uwb_object_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.uwb_object_type_id_seq OWNER TO uwb;

--
-- Name: uwb_object_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.uwb_object_type_id_seq OWNED BY public.uwb_object_type.id;


--
-- Name: uwb_user; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.uwb_user (
    deleted boolean,
    created_date timestamp(6) without time zone,
    id bigint NOT NULL,
    modified_date timestamp(6) without time zone,
    organization_unit_id bigint NOT NULL,
    created_by character varying(255),
    email character varying(50),
    first_name character varying(20),
    lang_key character varying(255),
    last_name character varying(30),
    modified_by character varying(255),
    password character varying(255),
    theme character varying(255)
);


ALTER TABLE public.uwb_user OWNER TO uwb;

--
-- Name: uwb_user_id_seq; Type: SEQUENCE; Schema: public; Owner: uwb
--

CREATE SEQUENCE public.uwb_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.uwb_user_id_seq OWNER TO uwb;

--
-- Name: uwb_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: uwb
--

ALTER SEQUENCE public.uwb_user_id_seq OWNED BY public.uwb_user.id;


--
-- Name: uwb_user_roles; Type: TABLE; Schema: public; Owner: uwb
--

CREATE TABLE public.uwb_user_roles (
    role_id bigint NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.uwb_user_roles OWNER TO uwb;

--
-- Name: anchor id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.anchor ALTER COLUMN id SET DEFAULT nextval('public.anchor_id_seq'::regclass);


--
-- Name: area id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.area ALTER COLUMN id SET DEFAULT nextval('public.area_id_seq'::regclass);


--
-- Name: area_type id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.area_type ALTER COLUMN id SET DEFAULT nextval('public.area_type_id_seq'::regclass);


--
-- Name: area_vertex id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.area_vertex ALTER COLUMN id SET DEFAULT nextval('public.area_vertex_id_seq'::regclass);


--
-- Name: background id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.background ALTER COLUMN id SET DEFAULT nextval('public.background_id_seq'::regclass);


--
-- Name: notification_config id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.notification_config ALTER COLUMN id SET DEFAULT nextval('public.notification_config_id_seq'::regclass);


--
-- Name: notification_type id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.notification_type ALTER COLUMN id SET DEFAULT nextval('public.notification_type_id_seq'::regclass);


--
-- Name: organization_unit id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.organization_unit ALTER COLUMN id SET DEFAULT nextval('public.organization_unit_id_seq'::regclass);


--
-- Name: role id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- Name: tag_a28we1 id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.tag_a28we1 ALTER COLUMN id SET DEFAULT nextval('public.tag_a28we1_id_seq'::regclass);


--
-- Name: tag_cqw34e id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.tag_cqw34e ALTER COLUMN id SET DEFAULT nextval('public.tag_cqw34e_id_seq'::regclass);


--
-- Name: tag_po85uxc id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.tag_po85uxc ALTER COLUMN id SET DEFAULT nextval('public.tag_po85uxc_id_seq'::regclass);


--
-- Name: tag_poiu987 id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.tag_poiu987 ALTER COLUMN id SET DEFAULT nextval('public.tag_poiu987_id_seq'::regclass);


--
-- Name: tag_qwe12rt id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.tag_qwe12rt ALTER COLUMN id SET DEFAULT nextval('public.tag_qwe12rt_id_seq'::regclass);


--
-- Name: uwb_object id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.uwb_object ALTER COLUMN id SET DEFAULT nextval('public.uwb_object_id_seq'::regclass);


--
-- Name: uwb_object_icon id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.uwb_object_icon ALTER COLUMN id SET DEFAULT nextval('public.uwb_object_icon_id_seq'::regclass);


--
-- Name: uwb_object_type id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.uwb_object_type ALTER COLUMN id SET DEFAULT nextval('public.uwb_object_type_id_seq'::regclass);


--
-- Name: uwb_user id; Type: DEFAULT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.uwb_user ALTER COLUMN id SET DEFAULT nextval('public.uwb_user_id_seq'::regclass);


--
-- Data for Name: anchor; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.anchor (id, created_by, created_date, deleted, modified_by, modified_date, name, x, x_px, y, y_px, z, background_id) FROM stdin;
\.
COPY public.anchor (id, created_by, created_date, deleted, modified_by, modified_date, name, x, x_px, y, y_px, z, background_id) FROM '$$PATH$$/3534.dat';

--
-- Data for Name: area; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.area (id, created_by, created_date, deleted, modified_by, modified_date, color, name, area_type_id, background_id) FROM stdin;
\.
COPY public.area (id, created_by, created_date, deleted, modified_by, modified_date, color, name, area_type_id, background_id) FROM '$$PATH$$/3528.dat';

--
-- Data for Name: area_type; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.area_type (id, created_by, created_date, deleted, modified_by, modified_date, color, name, organization_unit_id) FROM stdin;
\.
COPY public.area_type (id, created_by, created_date, deleted, modified_by, modified_date, color, name, organization_unit_id) FROM '$$PATH$$/3530.dat';

--
-- Data for Name: area_vertex; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.area_vertex (id, lp, x, y, area_id) FROM stdin;
\.
COPY public.area_vertex (id, lp, x, y, area_id) FROM '$$PATH$$/3532.dat';

--
-- Data for Name: areas_notifications; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.areas_notifications (notification_id, area_id) FROM stdin;
\.
COPY public.areas_notifications (notification_id, area_id) FROM '$$PATH$$/3543.dat';

--
-- Data for Name: background; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.background (id, created_by, created_date, deleted, modified_by, modified_date, file_name, file_size, name, path, scale, organization_unit_id) FROM stdin;
\.
COPY public.background (id, created_by, created_date, deleted, modified_by, modified_date, file_name, file_size, name, path, scale, organization_unit_id) FROM '$$PATH$$/3520.dat';

--
-- Data for Name: localization_cache; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.localization_cache (id, date, x, y, z, tag_id, background_id, anchor_ids) FROM stdin;
\.
COPY public.localization_cache (id, date, x, y, z, tag_id, background_id, anchor_ids) FROM '$$PATH$$/3535.dat';

--
-- Data for Name: notification_config; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.notification_config (id, message, title, notification_type_id) FROM stdin;
\.
COPY public.notification_config (id, message, title, notification_type_id) FROM '$$PATH$$/3545.dat';

--
-- Data for Name: notification_type; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.notification_type (id, name) FROM stdin;
\.
COPY public.notification_type (id, name) FROM '$$PATH$$/3547.dat';

--
-- Data for Name: organization_unit; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.organization_unit (deleted, created_date, id, modified_date, parent_organization_unit_id, created_by, modified_by, name, tree_path) FROM stdin;
\.
COPY public.organization_unit (deleted, created_date, id, modified_date, parent_organization_unit_id, created_by, modified_by, name, tree_path) FROM '$$PATH$$/3513.dat';

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.role (id, name) FROM stdin;
\.
COPY public.role (id, name) FROM '$$PATH$$/3515.dat';

--
-- Data for Name: tag_a28we1; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.tag_a28we1 (id, date, x, y, z, tag_id, background_id, anchor_ids) FROM stdin;
\.
COPY public.tag_a28we1 (id, date, x, y, z, tag_id, background_id, anchor_ids) FROM '$$PATH$$/3538.dat';

--
-- Data for Name: tag_cqw34e; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.tag_cqw34e (id, date, x, y, z, tag_id, background_id, anchor_ids) FROM stdin;
\.
COPY public.tag_cqw34e (id, date, x, y, z, tag_id, background_id, anchor_ids) FROM '$$PATH$$/3549.dat';

--
-- Data for Name: tag_po85uxc; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.tag_po85uxc (id, date, x, y, z, tag_id, background_id, anchor_ids) FROM stdin;
\.
COPY public.tag_po85uxc (id, date, x, y, z, tag_id, background_id, anchor_ids) FROM '$$PATH$$/3542.dat';

--
-- Data for Name: tag_poiu987; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.tag_poiu987 (id, date, x, y, z, tag_id, background_id, anchor_ids) FROM stdin;
\.
COPY public.tag_poiu987 (id, date, x, y, z, tag_id, background_id, anchor_ids) FROM '$$PATH$$/3551.dat';

--
-- Data for Name: tag_qwe12rt; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.tag_qwe12rt (id, date, x, y, z, tag_id, background_id, anchor_ids) FROM stdin;
\.
COPY public.tag_qwe12rt (id, date, x, y, z, tag_id, background_id, anchor_ids) FROM '$$PATH$$/3540.dat';

--
-- Data for Name: uwb_object; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.uwb_object (id, created_by, created_date, deleted, modified_by, modified_date, hex_tag_id, name, second_name, uwb_object_type_id) FROM stdin;
\.
COPY public.uwb_object (id, created_by, created_date, deleted, modified_by, modified_date, hex_tag_id, name, second_name, uwb_object_type_id) FROM '$$PATH$$/3522.dat';

--
-- Data for Name: uwb_object_icon; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.uwb_object_icon (id, created_by, created_date, deleted, modified_by, modified_date, file_name, name, path, file_size, organization_unit_id) FROM stdin;
\.
COPY public.uwb_object_icon (id, created_by, created_date, deleted, modified_by, modified_date, file_name, name, path, file_size, organization_unit_id) FROM '$$PATH$$/3524.dat';

--
-- Data for Name: uwb_object_type; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.uwb_object_type (id, created_by, created_date, deleted, modified_by, modified_date, admin_only, name, organization_unit_id, uwb_object_icon_id) FROM stdin;
\.
COPY public.uwb_object_type (id, created_by, created_date, deleted, modified_by, modified_date, admin_only, name, organization_unit_id, uwb_object_icon_id) FROM '$$PATH$$/3526.dat';

--
-- Data for Name: uwb_user; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.uwb_user (deleted, created_date, id, modified_date, organization_unit_id, created_by, email, first_name, lang_key, last_name, modified_by, password, theme) FROM stdin;
\.
COPY public.uwb_user (deleted, created_date, id, modified_date, organization_unit_id, created_by, email, first_name, lang_key, last_name, modified_by, password, theme) FROM '$$PATH$$/3517.dat';

--
-- Data for Name: uwb_user_roles; Type: TABLE DATA; Schema: public; Owner: uwb
--

COPY public.uwb_user_roles (role_id, user_id) FROM stdin;
\.
COPY public.uwb_user_roles (role_id, user_id) FROM '$$PATH$$/3518.dat';

--
-- Name: anchor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.anchor_id_seq', 14, true);


--
-- Name: area_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.area_id_seq', 13, true);


--
-- Name: area_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.area_type_id_seq', 10, true);


--
-- Name: area_vertex_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.area_vertex_id_seq', 76, true);


--
-- Name: background_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.background_id_seq', 10, true);


--
-- Name: localization_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.localization_cache_id_seq', 807, true);


--
-- Name: notification_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.notification_config_id_seq', 6, true);


--
-- Name: notification_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.notification_type_id_seq', 2, true);


--
-- Name: organization_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.organization_unit_id_seq', 11, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.role_id_seq', 1, true);


--
-- Name: tag_a28we1_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.tag_a28we1_id_seq', 1, true);


--
-- Name: tag_cqw34e_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.tag_cqw34e_id_seq', 23, true);


--
-- Name: tag_po85uxc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.tag_po85uxc_id_seq', 377, true);


--
-- Name: tag_poiu987_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.tag_poiu987_id_seq', 23, true);


--
-- Name: tag_qwe12rt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.tag_qwe12rt_id_seq', 378, true);


--
-- Name: uwb_object_icon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.uwb_object_icon_id_seq', 8, true);


--
-- Name: uwb_object_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.uwb_object_id_seq', 20, true);


--
-- Name: uwb_object_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.uwb_object_type_id_seq', 6, true);


--
-- Name: uwb_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: uwb
--

SELECT pg_catalog.setval('public.uwb_user_id_seq', 4, true);


--
-- Name: anchor anchor_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.anchor
    ADD CONSTRAINT anchor_pkey PRIMARY KEY (id);


--
-- Name: area area_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.area
    ADD CONSTRAINT area_pkey PRIMARY KEY (id);


--
-- Name: area_type area_type_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.area_type
    ADD CONSTRAINT area_type_pkey PRIMARY KEY (id);


--
-- Name: area_vertex area_vertex_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.area_vertex
    ADD CONSTRAINT area_vertex_pkey PRIMARY KEY (id);


--
-- Name: background background_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.background
    ADD CONSTRAINT background_pkey PRIMARY KEY (id);


--
-- Name: localization_cache localization_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.localization_cache
    ADD CONSTRAINT localization_cache_pkey PRIMARY KEY (id);


--
-- Name: notification_config notification_config_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.notification_config
    ADD CONSTRAINT notification_config_pkey PRIMARY KEY (id);


--
-- Name: notification_type notification_type_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.notification_type
    ADD CONSTRAINT notification_type_pkey PRIMARY KEY (id);


--
-- Name: organization_unit organization_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.organization_unit
    ADD CONSTRAINT organization_unit_pkey PRIMARY KEY (id);


--
-- Name: role role_name_key; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_name_key UNIQUE (name);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- Name: tag_a28we1 tag_a28we1_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.tag_a28we1
    ADD CONSTRAINT tag_a28we1_pkey PRIMARY KEY (id);


--
-- Name: tag_cqw34e tag_cqw34e_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.tag_cqw34e
    ADD CONSTRAINT tag_cqw34e_pkey PRIMARY KEY (id);


--
-- Name: tag_po85uxc tag_po85uxc_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.tag_po85uxc
    ADD CONSTRAINT tag_po85uxc_pkey PRIMARY KEY (id);


--
-- Name: tag_poiu987 tag_poiu987_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.tag_poiu987
    ADD CONSTRAINT tag_poiu987_pkey PRIMARY KEY (id);


--
-- Name: tag_qwe12rt tag_qwe12rt_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.tag_qwe12rt
    ADD CONSTRAINT tag_qwe12rt_pkey PRIMARY KEY (id);


--
-- Name: uwb_object_icon uwb_object_icon_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.uwb_object_icon
    ADD CONSTRAINT uwb_object_icon_pkey PRIMARY KEY (id);


--
-- Name: uwb_object uwb_object_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.uwb_object
    ADD CONSTRAINT uwb_object_pkey PRIMARY KEY (id);


--
-- Name: uwb_object_type uwb_object_type_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.uwb_object_type
    ADD CONSTRAINT uwb_object_type_pkey PRIMARY KEY (id);


--
-- Name: uwb_user uwb_user_pkey; Type: CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.uwb_user
    ADD CONSTRAINT uwb_user_pkey PRIMARY KEY (id);


--
-- Name: uwb_user fk2vpl8w2mbo643iiyilm5gu5h2; Type: FK CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.uwb_user
    ADD CONSTRAINT fk2vpl8w2mbo643iiyilm5gu5h2 FOREIGN KEY (organization_unit_id) REFERENCES public.organization_unit(id);


--
-- Name: areas_notifications fk3ci4qp5qgti8b1qb7gd7f3rgy; Type: FK CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.areas_notifications
    ADD CONSTRAINT fk3ci4qp5qgti8b1qb7gd7f3rgy FOREIGN KEY (area_id) REFERENCES public.area(id);


--
-- Name: uwb_user_roles fk6so7hslrq0bj8r8ojlu2tihaw; Type: FK CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.uwb_user_roles
    ADD CONSTRAINT fk6so7hslrq0bj8r8ojlu2tihaw FOREIGN KEY (role_id) REFERENCES public.role(id);


--
-- Name: area_type fkb4u6k769va6v08311oeq2jlon; Type: FK CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.area_type
    ADD CONSTRAINT fkb4u6k769va6v08311oeq2jlon FOREIGN KEY (organization_unit_id) REFERENCES public.organization_unit(id);


--
-- Name: uwb_user_roles fkbmp3rptv5oeqy0gdoqoeaappg; Type: FK CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.uwb_user_roles
    ADD CONSTRAINT fkbmp3rptv5oeqy0gdoqoeaappg FOREIGN KEY (user_id) REFERENCES public.uwb_user(id);


--
-- Name: anchor fkcrmqbjscsoon67ir7yu64gid3; Type: FK CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.anchor
    ADD CONSTRAINT fkcrmqbjscsoon67ir7yu64gid3 FOREIGN KEY (background_id) REFERENCES public.background(id);


--
-- Name: uwb_object_type fkf5epc01slcg1s5giyy7cyx7uo; Type: FK CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.uwb_object_type
    ADD CONSTRAINT fkf5epc01slcg1s5giyy7cyx7uo FOREIGN KEY (uwb_object_icon_id) REFERENCES public.uwb_object_icon(id);


--
-- Name: notification_config fkfkaibrhonu9kv5d2t39vnrcot; Type: FK CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.notification_config
    ADD CONSTRAINT fkfkaibrhonu9kv5d2t39vnrcot FOREIGN KEY (notification_type_id) REFERENCES public.notification_type(id);


--
-- Name: areas_notifications fkgghqhacl39bxla6vijqy1mcdj; Type: FK CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.areas_notifications
    ADD CONSTRAINT fkgghqhacl39bxla6vijqy1mcdj FOREIGN KEY (notification_id) REFERENCES public.notification_config(id);


--
-- Name: area fkjm5wnlok583mv21t3tpitmwjj; Type: FK CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.area
    ADD CONSTRAINT fkjm5wnlok583mv21t3tpitmwjj FOREIGN KEY (background_id) REFERENCES public.background(id);


--
-- Name: area_vertex fklbxyvo2gs56n66v4gxr79lndw; Type: FK CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.area_vertex
    ADD CONSTRAINT fklbxyvo2gs56n66v4gxr79lndw FOREIGN KEY (area_id) REFERENCES public.area(id);


--
-- Name: uwb_object_type fklucvayktj3uffuojifa7sebka; Type: FK CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.uwb_object_type
    ADD CONSTRAINT fklucvayktj3uffuojifa7sebka FOREIGN KEY (organization_unit_id) REFERENCES public.organization_unit(id);


--
-- Name: background fkn71mc0vat9kxx2xa1cuwcfv7g; Type: FK CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.background
    ADD CONSTRAINT fkn71mc0vat9kxx2xa1cuwcfv7g FOREIGN KEY (organization_unit_id) REFERENCES public.organization_unit(id);


--
-- Name: area fknthup5wgq7m7rk8dkpoewbuyv; Type: FK CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.area
    ADD CONSTRAINT fknthup5wgq7m7rk8dkpoewbuyv FOREIGN KEY (area_type_id) REFERENCES public.area_type(id);


--
-- Name: uwb_object fkqcgv59c13vu7upgppphs4vdc9; Type: FK CONSTRAINT; Schema: public; Owner: uwb
--

ALTER TABLE ONLY public.uwb_object
    ADD CONSTRAINT fkqcgv59c13vu7upgppphs4vdc9 FOREIGN KEY (uwb_object_type_id) REFERENCES public.uwb_object_type(id);


--
-- PostgreSQL database dump complete
--

